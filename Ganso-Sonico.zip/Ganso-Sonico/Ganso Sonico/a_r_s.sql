-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2013 at 09:33 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_medARACTER_SET_CLIENT=@@medARACTER_SET_CLIENT */;
/*!40101 SET @OLD_medARACTER_SET_RESULTS=@@medARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `a_r_s`
--

-- --------------------------------------------------------

--
-- Table structure for table `aircraft`
--

CREATE TABLE IF NOT EXISTS `aircraft` (
  `aircraftTypeID` varchar(10) NOT NULL,
  `description` varchar(50) DEFAULT NULL,
  `xseats` int(3) DEFAULT NULL,
  `eseats` int(3) DEFAULT NULL,
  PRIMARY KEY (`aircraftTypeID`)
) ENGINE=InnoDB DEFAULT medARSET=latin1;

--
-- Dumping data for table `aircraft`
--

INSERT INTO `aircraft` (`aircraftTypeID`, `description`, `xseats`, `eseats`) VALUES
('GS075', 'GANSO AIRBUS 075', 50, 110),
('GS085', 'GANSO AIRBUS 085', 75, 110),
('GS090', 'GANSO AIRBUS 090', 150, 200),
('GS092', 'GANSO AIRBUS 092', 80, 0),
('GS191', 'GANSO AIRBUS 191', 200, 200),
('GS192', 'GANSO AIRBUS 192', 200, 0),
('GS253', 'GANSO AIRBUS 253', 80, 80),
('GS273', 'GANSO AIRBUS 273', 55, 100),
('GS331', 'GANSO AIRBUS 331', 0, 250),
('GS332', 'GANSO AIRBUS 332', 0, 250),
('GS491', 'GANSO AIRBUS 491', 150, 200),
('GS927', 'GANSO AIRBUS 927', 75, 80),
('GS928', 'GANSO AIRBUS 928', 130, 130),
('GS930', 'GANSO AIRBUS 930', 150, 200),
('GS991', 'GANSO AIRBUS 991', 0, 120),
('GS992', 'GANSO AIRBUS 992', 100, 120);

-- --------------------------------------------------------

--
-- Table structure for table `dailycollections`
--

CREATE TABLE IF NOT EXISTS `dailycollections` (
  `pnrno` varchar(8) DEFAULT NULL,
  `trandate` date DEFAULT NULL,
  `trantype` varchar(15) DEFAULT NULL,
  `amount` decimal(9,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT medARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE IF NOT EXISTS `flights` (
  `flightno` varchar(6) NOT NULL,
  `deptime` varchar(5) DEFAULT NULL,
  `arrtime` varchar(5) DEFAULT NULL,
  `aircrafttypeID` varchar(6) DEFAULT NULL,
  `sectorID` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`flightno`)
) ENGINE=InnoDB DEFAULT medARSET=latin1;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`flightno`, `deptime`, `arrtime`, `aircrafttypeID`, `sectorID`) VALUES
('FGS11', '18:00', NULL, 'GS075', 'bgt-cal'),
('FGS12', '08:30', NULL, 'GS927', 'brqll-cali'),
('FGS16', NULL, NULL, NULL, 'brqll-med'),
('FGS19', '17:55', NULL, 'GS991', 'brqll-bgt'),
('FGS22', NULL, NULL, NULL, 'cal-pas'),
('FGS23', '00:30', NULL, 'GS930', 'cali-bgt'),
('FGS24', '21:40', NULL, 'GS991', 'cal-bgt'),
('FGS26', NULL, NULL, NULL, 'med-pas'),
('FGS27', NULL, NULL, NULL, 'cal-pas'),
('FGS31', '08:00', NULL, 'GS090', 'bgt-brqll'),
('FGS33', '15:00', NULL, 'GS192', 'cal-pas'),
('FGS40', '08:00', NULL, 'GS090', 'bgt-brqll'),
('FGS42', '07:35', NULL, 'GS332', 'brqll-cal'),
('FGS43', NULL, NULL, NULL, 'brqll-pas'),
('FGS45', NULL, NULL, NULL, 'brqll-pas'),
('FGS47', NULL, NULL, NULL, 'pas-med'),
('FGS55', '13:15', NULL, 'GS191', 'cal-brqll'),
('FGS58', '20:00', NULL, 'GS253', 'cal-brqll'),
('FGS67', '09:00', NULL, 'GS491', 'brqll-cal'),
('FGS71', NULL, NULL, NULL, 'brqll-pas'),
('FGS78', '21:30', NULL, 'GS273', 'brqll-bgt'),
('FGS81', NULL, NULL, NULL, 'brqll-bgt'),
('FGS87', '10:00', NULL, 'GS092', 'bgt-brqll'),
('FGS88', NULL, NULL, NULL, 'brqll-bgt'),
('FGS91', '00:25', NULL, 'GS330', 'brqll-cal'),
('FGS95', NULL, NULL, NULL, 'brqll-bgt'),
('FGS98', '13:00', NULL, 'GS085', 'bgt-cal'),
('FGS99', '12:30', NULL, 'GS992', 'cal-bgt');

-- --------------------------------------------------------
--
-- Table structure for table `premio`
--

CREATE TABLE IF NOT EXISTS `premio` (
  `priceID` varchar(6) NOT NULL,
  `nameprice` varchar(30) DEFAULT NULL,
  `points` varchar(15) DEFAULT NULL,
   PRIMARY KEY (`priceID`)
) ENGINE=InnoDB DEFAULT medARSET=latin1;

--
-- Dumping data for table `premio`
--

INSERT INTO `premio` (`priceID`, `nameprice`, `points`) VALUES
('PR01', 'comida gratis','10000'),
('PR02', 'trago gratis','20000'),
('PR03', 'entrada a VIP','30000'),
('PR04', 'pelicula gratis','40000'),
('PR05', 'transporte gratis','50000');
-- --------------------------------------------------------
--
-- Table structure for table `passengers`
--

CREATE TABLE IF NOT EXISTS `passengers` (
  `pnrno` varchar(8) NOT NULL,
  `flightno` varchar(5) DEFAULT NULL,
  `traveldate` date DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(50) DEFAULT NULL,
  `age` int(2) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `class` varchar(15) DEFAULT NULL,
  `noa` int(2) DEFAULT '1',
  `noc` int(2) NOT NULL DEFAULT '0',
  `status` varchar(15) DEFAULT NULL,
   PRIMARY KEY (`pnrno`)
) ENGINE=InnoDB DEFAULT medARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `smededuledflights`
--

CREATE TABLE IF NOT EXISTS `smededuledflights` (
  `smededuleID` varchar(5) NOT NULL,
  `flightno` varchar(5) DEFAULT NULL,
  `flightdate` date DEFAULT NULL,
  `bcsavailable` int(2) DEFAULT NULL,
  `xcsavailable` int(3) DEFAULT NULL,
  `ecsavailable` int(3) DEFAULT NULL,
  PRIMARY KEY (`smededuleID`)
) ENGINE=InnoDB DEFAULT medARSET=latin1;

--
-- Dumping data for table `smededuledflights`
--

INSERT INTO `smededuledflights` (`smededuleID`, `flightno`, `flightdate`, `xcsavailable`, `ecsavailable`) VALUES
('00001', 'FGS11', '2016-06-16', 50, 110),
('00002', 'FGS12', '2016-06-18', 75, 80),
('00003', 'FGS24', '2016-06-18', 150, 200),
('00004', 'FGS19', '2016-06-17', 0, 120),
('00005', 'FGS31', '2016-06-17', 150, 200),
('00006', 'FGS33', '2016-06-17', 200, 0),
('00007', 'FGS40', '2016-06-16', 150, 200),
('00008', 'FGS42', '2016-06-18', 0, 250),
('00009', 'FGS55', '2016-06-16', 200, 200),
('00010', 'FGS58', '2016-06-16', 80, 80),
('00011', 'FGS67', '2016-06-16', 150, 200),
('00012', 'FGS78', '2016-06-16', 55, 100),
('00013', 'FGS87', '2016-06-16', 80, 0),
('00014', 'FGS91', '2016-06-17', 0, 250),
('00015', 'FGS98', '2016-06-17', 75, 110),
('00016', 'FGS99', '2016-06-18', 100, 120);

-- --------------------------------------------------------

--
-- Table structure for table `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
  `sectorID` varchar(5) NOT NULL,
  `source` varchar(25) DEFAULT NULL,
  `destination` varchar(25) NOT NULL,
  `weekday1` varchar(4) DEFAULT NULL,
  `weekday2` varchar(4) DEFAULT NULL,
  `weekday3` varchar(4) DEFAULT NULL,
  `xfare` decimal(8,2) DEFAULT '0.00',
  `efare` decimal(8,2) DEFAULT '0.00',
  PRIMARY KEY (`sectorID`)
) ENGINE=InnoDB DEFAULT medARSET=latin1;

--
-- Dumping data for table `sector`
--

INSERT INTO `sector` (`sectorID`, `source`, `destination`, `weekday1`, `weekday2`, `weekday3`, `xfare`, `efare`) VALUES
('ad-med', 'Bogota', 'Medellin', 'WED', 'MON', 'NULL', 7500.00, 0.00),
('bgt-brqll', 'Bogota', 'Barranquilla', 'TUE', 'TUE', 'THR', 0.00, 5664.00),
('bgt-cal', 'Bogota', 'Cali', 'MON', 'TUE', 'WED', 3560.00, 2563.00),
('bgt-pas', 'Bogota', 'Pasto', 'SUN', 'SAT', 'NULL', 5700.00, 4500.00),
('med-bgt', 'Medellin', 'Bogota', 'FRI', 'SAT', 'NULL', 6500.00, 4500.00),
('med-brqll', 'Medellin', 'Barranquilla', 'FRI', 'WED', 'MON', 8954.00, 6789.00),
('med-cal', 'Medellin', 'Cali', 'THR', 'TUE', 'SAT', 9800.00, 6555.00),
('med-cal', 'Medellin', 'Cali', 'SAT', 'FRI', 'SUN', 4400.00, 3200.00),
('med-pas', 'Medellin', 'Pasto', 'MON', 'TUE', 'WED', 11550.00, 9540.00),
('brqll-bgt', 'Barranquilla', 'Bogota', 'TUE', 'WED', 'THR', 7500.00, 4660.00),
('brqll-med', 'Barranquilla', 'Medellin', 'FRI', 'MON', 'WED', 8990.00, 6450.00),
('brqll-cal', 'Barranquilla', 'Cali', 'SUN', 'TUE', 'WED', 9900.00, 5630.00),
('brqll-pas', 'Barranquilla', 'Pasto', 'TUE', 'SAT', 'NULL', 4200.00, 3200.00),
('bgt-cal', 'Bogota', 'Cali', 'MON', 'NULL', 'NULL', 8700.00, 0.00),
('cal-bgt', 'Cali', 'Bogota', 'SUN', 'MON', 'MON', 0.00, 5750.00),
('cal-med', 'Cali', 'Medellin', 'TUE', 'MON', 'WED', 0.00, 6450.00),
('cal-brqll', 'Cali', 'Barranquilla', 'MON', 'TUE', 'NULL', 12300.00, 8600.00),
('cal-bgt', 'Cali', 'Bogota', 'WED', 'NULL', 'NULL', 10000.00, 0.00),
('cal-pas', 'Cali', 'Pasto', 'TUE', 'SAT', 'FRI', 11000.00, 10000.00),
('cal-med', 'Cali', 'Medellin', 'WED', 'THR', 'NULL', 5000.00, 4000.00),
('pas-bgt', 'Pasto', 'Bogota', 'THR', 'FRI', 'SAT', 5120.00, 0.00),
('pas-med', 'Pasto', 'Medellin', 'FRI', 'SAT', 'SUN', 6375.00, 4550.00),
('pas-brqll', 'Pasto', 'Barranquilla', 'SAT', 'TUE', 'THR',  12500.00, 10500.00),
('pas-cal', 'Pasto', 'Cali', 'SUN', 'SAT', 'FRI', 0.00, 6800.00);

-- --------------------------------------------------------

--
-- Table structure for table `user_profile`
--

CREATE TABLE IF NOT EXISTS `user_profile` (
  `userid` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `contactno` bigint(10) NOT NULL,
  `dob` date NOT NULL,
  `address` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `country` text NOT NULL,
  `emailid` text NOT NULL,
  `password` text NOT NULL,
  `usertype` text NOT NULL,
  `username` text NOT NULL,
  `points` int(40) DEFAULT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB  DEFAULT medARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user_profile`
--

INSERT INTO `user_profile` (`userid`, `firstname`, `lastname`, `contactno`, `dob`, `address`, `city`, `state`, `country`, `emailid`, `password`, `usertype`, `username`, `points`) VALUES
(1, 'Juan', 'Amortegui', 12345678, '1995-08-09', 'banderas', 'bogota', 'Cundinamarca', 'Colombia', 'juans.amorteguip@konradlorenz.edu.co', '1234', 'ADMIN', 'juan', 'NULL'),
(2, 'Jose', 'Novoa', 12345678, '1969-07-27', 'villas de granada', 'bogota', 'Cundinamarca', 'Colombia', 'josel.novoan@konradlorenz.edu.co', '1234', 'MANAGER', 'jose', 'NULL'),
(3, 'David', 'Guavita', 12345678, '1769-07-27', 'la granja', 'bogota', 'Cundinamarca', 'Colombia', 'davide.guavitad@konradlorenz.edu.co', '1234', 'USER', 'david','50000'),
(4, 'Jesus', 'Cardenas', 12345678, '1789-07-27', 'tintal', 'bogota', 'Cundinamarca', 'Colombia', 'jesusa.cardenasl@konradlorenz.edu.co', '1234', 'USER', 'jesus', '60000');
/*!40101 SET medARACTER_SET_CLIENT=@OLD_medARACTER_SET_CLIENT */;
/*!40101 SET medARACTER_SET_RESULTS=@OLD_medARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
